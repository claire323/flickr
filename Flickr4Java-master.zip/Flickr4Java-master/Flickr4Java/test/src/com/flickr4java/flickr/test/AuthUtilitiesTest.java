package com.flickr4java.flickr.test;

import org.junit.Ignore;

/**
 * Test the AuthUtilities.
 * 
 * @author Anthony Eden
 */
@Ignore
public class AuthUtilitiesTest {

}
