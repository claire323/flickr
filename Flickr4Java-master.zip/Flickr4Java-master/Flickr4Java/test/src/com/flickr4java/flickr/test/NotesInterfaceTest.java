/**
 * @author acaplan
 */
package com.flickr4java.flickr.test;

import static org.junit.Assert.fail;

import org.junit.Ignore;
import org.junit.Test;

/**
 * @author acaplan
 * 
 */
public class NotesInterfaceTest extends Flickr4JavaTest {

    /**
     * Test method for {@link com.flickr4java.flickr.photos.notes.NotesInterface#add(java.lang.String, com.flickr4java.flickr.photos.Note)}.
     */
    @Ignore("Haven't coded this yet")
    @Test
    public void testAdd() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link com.flickr4java.flickr.photos.notes.NotesInterface#delete(java.lang.String)}.
     */
    @Ignore("Haven't coded this yet")
    @Test
    public void testDelete() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link com.flickr4java.flickr.photos.notes.NotesInterface#edit(com.flickr4java.flickr.photos.Note)}.
     */
    @Ignore("Haven't coded this yet")
    @Test
    public void testEdit() {
        fail("Not yet implemented");
    }

}
