package com.flickr4java.flickr.groups;

import com.flickr4java.flickr.SearchResultList;

public class GroupList<E> extends SearchResultList<Group> {
    private static final long serialVersionUID = 3344960036515265775L;

}
