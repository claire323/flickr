package com.flickr4java.flickr.galleries;

import com.flickr4java.flickr.SearchResultList;

/**
 * @author acaplan
 * 
 */
public class GalleryList<T> extends SearchResultList<Gallery> {

    private static final long serialVersionUID = 8615256591460951313L;

}
