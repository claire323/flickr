package com.flickr4java.flickr.machinetags;

import com.flickr4java.flickr.SearchResultList;

/**
 * 
 * @author mago
 * @version $Id: NamespacesList.java,v 1.2 2009/07/12 22:43:07 x-mago Exp $
 */
public class NamespacesList<E> extends SearchResultList<E> {
    private static final long serialVersionUID = 12L;
}
