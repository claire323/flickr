package com.flickr4java.flickr.stats;

import com.flickr4java.flickr.SearchResultList;

/**
 * 
 * @author Darren Greaves
 */
public class DomainList extends SearchResultList<Domain> {

}
